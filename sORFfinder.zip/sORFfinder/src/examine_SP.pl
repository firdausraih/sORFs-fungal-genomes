use lib('/home/hanada/sORF_pp/sORFfinder/src');
use Distributions;

for(my $i=0; $i<@ARGV; $i++){
        if($ARGV[$i] eq "-i"){
                $sORF=$ARGV[$i+1];
                $ARGV[$i]=-1; $ARGV[$i+1]=-1;
        }
        elsif($ARGV[$i] eq "-l"){
                $LIST=$ARGV[$i+1];
                $ARGV[$i]=-1; $ARGV[$i+1]=-1;
        }
        elsif($ARGV[$i] eq "-o"){
                $OUT=$ARGV[$i+1];
                $ARGV[$i]=-1; $ARGV[$i+1]=-1;
        }
}

if(@ARGV==0){
print "examine_SP.pl -i \"sORF sequence\" -l \a file including the files of homology\" -o \"output file\"\n";
exit 1;
}
for(my $i=0; $i<@ARGV; $i++){
        if($ARGV[$i]!=-1){
print "examine_SP.pl -i \"sORF sequence\" -l \a file including the files of homology\" -o \"output file\"\n";
exit 1;
        }
}
if($OUT eq ""){
	print "please put name of output\n";
	exit 1;
}
unless(-f $sORF){
        print "can not find file: $sORF\n";
        exit 1;
}
unless(-f $LIST){
        print "can not find file: $LIST\n";
        exit 1;
}
open(in, $LIST);
while(<in>){
	if(/^(\S+)/){
		$homo_file=$1;
		unless(-f $homo_file){
        		print "can not find file: $homo_file\n";
        		exit 1;
		}
	}
}
close in;
if(-f $OUT){
        unlink $OUT;
}

%aalist = qw(
atg     M       tat     Y       gca     A       gcc     A
gcg     A       gct     A       tgc     C       tgt     C
gac     D       gat     D       gaa     E       gag     E
ttt     F       ttc     F       gga     G       ggc     G
ggg     G       ggt     G       cac     H       cat     H
ata     I       atc     I       att     I       aaa     K
aag     K       tta     L       ttg     L       cta     L
ctc     L       ctg     L       ctt     L       tgg     W
aac     N       aat     N       cca     P       ccc     P
ccg     P       cct     P       caa     Q       cag     Q
aga     R       agg     R       cga     R       cgc     R
cgg     R       cgt     R       agc     S       agt     S
tca     S       tcc     S       tcg     S       tct     S
aca     T       acc     T       acg     T       act     T
gta     V       gtc     V       gtg     V       gtt     V
tac     Y       taa     .       tag     .       tga     .
);

open(in, $sORF);
while(<in>){
	if(/^>(\S+)/){
		$name=$1;
		if($done{$name}==1){
			print "error! use redundant seq name\n";
			exit 1;
		}
		push(@NAME,$name);
		$done{$name}=1;
	}
	elsif(/(\S+)/){
		$SEQ{$name}=$SEQ{$name}.$1;
	}
}
close in;

for(my $i=0; $i<@NAME; $i++){
        undef $aa_seq;
        for(my $j=0; $j<length($SEQ{$NAME[$i]})/3; $j++){
                $cod=substr($SEQ{$NAME[$i]},$j*3,3);
                $cod=~ tr/A-Z/a-z/;
                if( $cod =~ /[atgc]{3}/){
                        $aa_seq = $aa_seq.$aalist{$cod};
                }
                elsif( $cod =~ /[a-z]{3}/){
                        print "error! some nucleotides does not have A,T,G,C in sORF sequences\n";
                }
                elsif( $cod eq "---"){
                        print "error! some nucleotides does not have A,T,G,C in sORF sequences\n";
                }
        }
        $SEQ_aa{$NAME[$i]}=$aa_seq;
}
close out;

open(in, $LIST);
while(<in>){
	if(/^(\S+)/){
		$homo_file=$1;
		open(in_homo, $homo_file);
		while(<in_homo>){
			if(/^>(\S+)/){
				push(@NAME_Q,$1);
			}
			elsif(/(\w+)/){
				push(@SEQU_D,$1);
			}
		}
		close in_homo;
	}
}
close in;

open(OUT, "> $OUT");
for(my $i=0; $i<@NAME; $i++){
	undef @temp_seq;
	for(my $j=0; $j<@NAME_Q; $j++){
		if($NAME[$i] eq $NAME_Q[$j]){
			push(@temp_seq,$SEQU_D[$j]);
		}
	}
	undef %seen;
	@temp_seq=grep(!$seen{$_}++,@temp_seq);
	undef @orf_seq; undef @data_seq;
	if(@temp_seq==0){
		print OUT ">$NAME[$i]\n\n";
		print OUT "No_homolog\n";
		print OUT "\n";
		next;
	}
	print OUT ">$NAME[$i]\n";
	for(my $j=0; $j<@temp_seq; $j++){
		undef $aa_seq;
		for(my $n=0; $n<length($temp_seq[$j])/3; $n++){
			$cod=substr($temp_seq[$j],$n*3,3);
			$cod=~ tr/A-Z/a-z/;
			if( $cod =~ /[atgc]{3}/){
				$aa_seq = $aa_seq.$aalist{$cod};
			}
			elsif( $cod =~ /[a-z]{3}/){$aa_seq=$aa_seq."X";}
			elsif( $cod eq "---"){$aa_seq=$aa_seq."X";}
		}
		open(out, "> tmp1");
		print out ">sORF\n";
		print out "$SEQ_aa{$NAME[$i]}\n";
		print out ">DATA\n";
		print out "$aa_seq\n";
		close out;
		################################
		`clustalw tmp1`; #please make a path to clustalw
		###############################
		undef %ALN;
		open(aaALN,"tmp1.aln");
		while(<aaALN>){
			print OUT;
		        if(/^(\S+)(\s\s\s+)((\w|\-)+)/i){
               			$aa = $3;
                		$ALN{$1} = $ALN{$1}.$aa;
        		}
		}
		close aaALN;

		@aa_sORF =split(//,$ALN{"sORF"});
		undef $t_seq; $num_of_gap=0;
		for(my $m = 0; $m < @aa_sORF; $m++){
			if($aa_sORF[$m] =~ /[A-Z]/i){
				$cut_seq = substr($SEQ{$NAME[$i]},($m-$num_of_gap)*3,3);
				$t_seq = $t_seq.$cut_seq;
			}
			elsif($aa_sORF[$m] eq "-"){	
				$t_seq = $t_seq."---";
				$num_of_gap++;
			}
		}
		$t_seq=~ tr/a-z/A-Z/;
		push(@orf_seq,$t_seq);
		@aa_DATA =split(//,$ALN{"DATA"});
		undef $t_seq; $num_of_gap=0;
		for(my $m = 0; $m < @aa_DATA; $m++){
			if($aa_DATA[$m] =~ /[A-Z]/i){
				$cut_seq = substr($temp_seq[$j],($m-$num_of_gap)*3,3);
				$t_seq = $t_seq.$cut_seq;
			}
			elsif($aa_DATA[$m] eq "-"){	
				$t_seq = $t_seq."---";
				$num_of_gap++;
			}
		}
		$t_seq=~ tr/a-z/A-Z/;
		push(@data_seq,$t_seq);
	}
	$R=&estimate_R;
	undef %syss; undef %nons;
	&estimate_sys_non($R);
	($sys_sub,$non_sub,$sys_site,$non_site)=&estimate_sub;
	if($non_site==0){
		$ka=9999;
	}
	else{
		$ka=$non_sub/$non_site;
	}
	if($sys_site==0){
		$ks=9999;
	}
	else{
		$ks=$sys_sub/$sys_site;
	}
	$A=$sys_sub; $B=$sys_site; $C=$non_sub; $D=$non_site;
	$Up=($A+$B+$C+$D)*(($A*$D)-($B*$C))*(($A*$D)-($B*$C));
	$Bo=($A+$B)*($C+$D)*($A+$C)*($B+$D);
	if($Bo!=0){
                $CHI=$Up/$Bo;
                $P=&Statistics::Distributions::chisqrprob(1,$CHI);
        }
	else{
		$P="ne";
	}
	if($ks!=0){
		$PRESSURE=$ka/$ks;
	}
	else{
		$PRESSURE=9999;
	}
	if($PRESSURE<1 and $P<0.05){
		print OUT "ka $ka\tks $ks\t$PRESSURE\t$P\tYES\n";
	}
	else{
		print OUT "ka $ka\tks $ks\t$PRESSURE\t$P\tNO\n";
	}
}
close OUT;

unlink $FASTA_aa;
unlink $FASTA_blast;
unlink "tmp1";
unlink "tmp1.aln";
unlink "tmp1.dnd";

sub estimate_sys_non{
	my $R=shift;
	my @nu=("a", "t", "g", "c");
	my @ref_codons;
	my ($b_trans,$b_tranv,$u_trans,$u_tranv);
	foreach $ref_codon (keys %aalist){
		$sys=0;
		if($ref_codon ne "tag" or $codon ne "taa" or $codon ne "tga"){
			push(@ref_codons, $ref_codon);
			@bara_codon=split(//, $ref_codon);
			$b_trans=0; $b_tranv=0; $u_trans=0; $u_tranv=0;
			for(my $n=0; $n<@nu; $n++){
				if($bara_codon[0] ne $nu[$n]){
					$temp_codon=$nu[$n].$bara_codon[1].$bara_codon[2];
					if($aalist{$temp_codon} ne "."){
						if   ($bara_codon[0] eq "a" and $nu[$n] eq "g") {$b_trans++;}
						elsif($bara_codon[0] eq "g" and $nu[$n] eq "a") {$b_trans++;}
						elsif($bara_codon[0] eq "c" and $nu[$n] eq "t") {$b_trans++;}
						elsif($bara_codon[0] eq "t" and $nu[$n] eq "c") {$b_trans++;}
						else{$b_tranv++;}
					}
					if($aalist{$temp_codon} eq $aalist{$ref_codon}){
						if   ($bara_codon[0] eq "a" and $nu[$n] eq "g") {$u_trans++;}
						elsif($bara_codon[0] eq "g" and $nu[$n] eq "a") {$u_trans++;}
						elsif($bara_codon[0] eq "c" and $nu[$n] eq "t") {$u_trans++;}
						elsif($bara_codon[0] eq "t" and $nu[$n] eq "c") {$u_trans++;}
						else{$u_tranv++;}
					}
				}
			}
			if   ($b_trans==1 and $b_tranv==2){$sys=$sys+($R/(1+$R))*$u_trans+(0.5/(1+$R))*$u_tranv;}
			elsif($b_trans==1 and $b_tranv==1){$sys=$sys+($R/(0.5+$R))*$u_trans+(0.5/(0.5+$R))*$u_tranv;}
			elsif($b_tranv==2)                {$sys=$sys+0.5*$u_tranv;}
			elsif($b_tranv==1)                {$sys=$sys+$u_tranv;}
			elsif($b_trans==1)                {$sys=$sys+$u_trans;}
	
			$b_trans=0; $b_tranv=0; $u_trans=0; $u_tranv=0;
			for(my $n=0; $n<@nu; $n++){
				if($bara_codon[2] ne $nu[$n]){
					$temp_codon=$bara_codon[0].$bara_codon[1].$nu[$n];
					if($aalist{$temp_codon} ne "."){
						if   ($bara_codon[2] eq "a" and $nu[$n] eq "g") {$b_trans++;}
						elsif($bara_codon[2] eq "g" and $nu[$n] eq "a") {$b_trans++;}
						elsif($bara_codon[2] eq "c" and $nu[$n] eq "t") {$b_trans++;}
						elsif($bara_codon[2] eq "t" and $nu[$n] eq "c") {$b_trans++;}
						else{$b_tranv++;}
					}
					if($aalist{$temp_codon} eq $aalist{$ref_codon}){
						if   ($bara_codon[2] eq "a" and $nu[$n] eq "g") {$u_trans++;}
						elsif($bara_codon[2] eq "g" and $nu[$n] eq "a") {$u_trans++;}
						elsif($bara_codon[2] eq "c" and $nu[$n] eq "t") {$u_trans++;}
						elsif($bara_codon[2] eq "t" and $nu[$n] eq "c") {$u_trans++;}
						else{$u_tranv++;}
					}
				}
			}
			if   ($b_trans==1 and $b_tranv==2){$sys=$sys+($R/(1+$R))*$u_trans+(0.5/(1+$R))*$u_tranv;}
			elsif($b_trans==1 and $b_tranv==1){$sys=$sys+($R/(0.5+$R))*$u_trans+(0.5/(0.5+$R))*$u_tranv;}
			elsif($b_tranv==2)                {$sys=$sys+0.5*$u_tranv;}
			elsif($b_tranv==1)                {$sys=$sys+$u_tranv;}
			elsif($b_trans==1)                {$sys=$sys+$u_trans;}
	
			$syss{$ref_codon}=$sys; $nons{$ref_codon}=3-$sys;
		}
	}
}

sub estimate_sub{
	my $S_sub=0; my $N_sub=0;
	my $sum_s_site=0; my $sum_n_site=0;
	for(my $n=0; $n<@orf_seq; $n++){
		my $S_site=0; my $N_site=0;
		for(my $i=0; $i<length($orf_seq[$n])/3; $i++){
			$codon1=substr($orf_seq[$n], $i*3,3);
			$codon2=substr($data_seq[$n],$i*3,3);
			$codon1=~ tr/A-Z/a-z/; $codon2=~ tr/A-Z/a-z/;
			$doing=1;
			if($codon1 =~ /taa|tag|tga/i or $codon2 =~ /taa|tag|tga/i){
				$doing=0;
			}
			if($codon1 =~ /-/i or $codon2 =~ /-/i){
				$doing=0;
			}
			if($doing == 1){
				$t_sys=($syss{$codon1}+$syss{$codon2})/2;
				$t_non=($nons{$codon1}+$nons{$codon2})/2;
				$S_site=$S_site+($syss{$codon1}+$syss{$codon2})/2;
				$N_site=$N_site+($nons{$codon1}+$nons{$codon2})/2;
				@s_n_sub=&sys_non_sub($codon1, $codon2);
				$S_sub=$S_sub+$s_n_sub[0];
				$N_sub=$N_sub+$s_n_sub[1];
			}
		}
		$sum_s_site=$sum_s_site+$S_site;
		$sum_n_site=$sum_n_site+$N_site;
	}
	return($S_sub,$N_sub,$sum_s_site,$sum_n_site)
}

##################ts/tv ratio##################
sub estimate_R{
	my $ts=0; my $tv=0;
	for(my $n=0; $n<@orf_seq; $n++){
		for(my $i=0; $i<length($orf_seq[$n]); $i++){
			$n_t_one=substr($orf_seq[$n], $i, 1);
			$n_t_two=substr($data_seq[$n], $i, 1);
			if($n_t_one ne $n_t_two){
				if($n_t_one eq "A" and $n_t_two eq "G"){$ts++;}
				elsif($n_t_one eq "T" and $n_t_two eq "C"){$ts++;}
				elsif($n_t_one eq "G" and $n_t_two eq "A"){$ts++;}
				elsif($n_t_one eq "C" and $n_t_two eq "T"){$ts++;}
				elsif($n_t_one eq "A" and $n_t_two eq "C"){$tv++;}
				elsif($n_t_one eq "A" and $n_t_two eq "T"){$tv++;}
				elsif($n_t_one eq "T" and $n_t_two eq "A"){$tv++;}
				elsif($n_t_one eq "T" and $n_t_two eq "G"){$tv++;}
				elsif($n_t_one eq "G" and $n_t_two eq "C"){$tv++;}
				elsif($n_t_one eq "G" and $n_t_two eq "T"){$tv++;}
				elsif($n_t_one eq "C" and $n_t_two eq "A"){$tv++;}
				elsif($n_t_one eq "C" and $n_t_two eq "G"){$tv++;}
			}
		}
	}
	if($tv==0){$R=2;}
	else{$R=$ts/$tv;}

	if($R>10 or $R<1){
		$R=2;
	}
	return($R);
}
############################################


#################sys sub, non sub##############################
sub sys_non_sub{
	my ($codon_one, $codon_two, @codon_one_bara, @codon_two_bara);
	my ($sys_sub, $non_sub, $dif);
	
	$codon_one=shift;
	$codon_two=shift;
	@codon_one_bara=split(//, $codon_one);
	@codon_two_bara=split(//, $codon_two);
	$dif=0; $sys_sub=0; $non_sub=0;
	for(my $a=0; $a<3; $a++){
		if($codon_one_bara[$a] ne $codon_two_bara[$a]){
			$dif++;
		}
	}
	if($dif==1){
		if($aalist{$codon_one} eq $aalist{$codon_two}){$sys_sub++;}
		else{$non_sub++;}
	}
	elsif($dif==2){
		$temp_sys=0; $temp_non=0;$div=0;
		if($codon_one_bara[2] eq $codon_two_bara[2]){
			$one_two=$codon_one_bara[0].$codon_two_bara[1].$codon_one_bara[2];
			if($aalist{$one_two} ne "."){
				$div++;
				if($aalist{$codon_one} eq $aalist{$one_two}){$temp_sys++;}
				else{$temp_non++;}
				if($aalist{$one_two} eq $aalist{$codon_two}){$temp_sys++;}
				else{$temp_non++;}
			}

			$one_two=$codon_two_bara[0].$codon_one_bara[1].$codon_one_bara[2];
			if($aalist{$one_two} ne "."){
				$div++;
				if($aalist{$codon_one} eq $aalist{$one_two}){$temp_sys++;}
				else{$temp_non++;}
				if($aalist{$one_two} eq $aalist{$codon_two}){$temp_sys++;}
				else{$temp_non++;}
			}
		}
		elsif($codon_one_bara[1] eq $codon_two_bara[1]){
			$one_two=$codon_one_bara[0].$codon_one_bara[1].$codon_two_bara[2];
			if($aalist{$one_two} ne "."){
				$div++;
				if($aalist{$codon_one} eq $aalist{$one_two}){$temp_sys++;}
				else{$temp_non++;}
				if($aalist{$one_two} eq $aalist{$codon_two}){$temp_sys++;}
				else{$temp_non++;}
			}

			$one_two=$codon_two_bara[0].$codon_one_bara[1].$codon_one_bara[2];
			if($aalist{$one_two} ne "."){
				$div++;
				if($aalist{$codon_one} eq $aalist{$one_two}){$temp_sys++;}
				else{$temp_non++;}
				if($aalist{$one_two} eq $aalist{$codon_two}){$temp_sys++;}
				else{$temp_non++;}
			}
		}
		elsif($codon_one_bara[0] eq $codon_two_bara[0]){
			$one_two=$codon_one_bara[0].$codon_one_bara[1].$codon_two_bara[2];
			if($aalist{$one_two} ne "."){
				$div++;
				if($aalist{$codon_one} eq $aalist{$one_two}){$temp_sys++;}
				else{$temp_non++;}
				if($aalist{$one_two} eq $aalist{$codon_two}){$temp_sys++;}
				else{$temp_non++;}
			}

			$one_two=$codon_one_bara[0].$codon_two_bara[1].$codon_one_bara[2];
			if($aalist{$one_two} ne "."){
				$div++;
				if($aalist{$codon_one} eq $aalist{$one_two}){$temp_sys++;}
				else{$temp_non++;}
				if($aalist{$one_two} eq $aalist{$codon_two}){$temp_sys++;}
				else{$temp_non++;}
			}
		
		}
		$sys_sub=$sys_sub+($temp_sys/$div);
		$non_sub=$non_sub+($temp_non/$div);
	}
	elsif($dif==3){
		$div=0;
		$temp_sys=0; $temp_non=0;
		$one_mid=$codon_one_bara[0].$codon_one_bara[1].$codon_two_bara[2];	
		$mid_two=$codon_one_bara[0].$codon_two_bara[1].$codon_two_bara[2];
		if($aalist{$one_mid} ne "." and $aalist{$mid_two} ne "."){
			$div++;
			if($aalist{$codon_one} eq $aalist{$one_mid}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$one_mid} eq $aalist{$mid_two}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$mid_two} eq $aalist{$codon_two}){$temp_sys++;}
			else{$temp_non++;}
		}

		$one_mid=$codon_one_bara[0].$codon_one_bara[1].$codon_two_bara[2];	
		$mid_two=$codon_two_bara[0].$codon_one_bara[1].$codon_two_bara[2];
		if($aalist{$one_mid} ne "." and $aalist{$mid_two} ne "."){
			$div++;
			if($aalist{$codon_one} eq $aalist{$one_mid}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$one_mid} eq $aalist{$mid_two}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$mid_two} eq $aalist{$codon_two}){$temp_sys++;}
			else{$temp_non++;}
		}

		$one_mid=$codon_one_bara[0].$codon_two_bara[1].$codon_one_bara[2];	
		$mid_two=$codon_one_bara[0].$codon_two_bara[1].$codon_two_bara[2];
		if($aalist{$one_mid} ne "." and $aalist{$mid_two} ne "."){
			$div++;
			if($aalist{$codon_one} eq $aalist{$one_mid}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$one_mid} eq $aalist{$mid_two}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$mid_two} eq $aalist{$codon_two}){$temp_sys++;}
			else{$temp_non++;}
		}

		$one_mid=$codon_one_bara[0].$codon_two_bara[1].$codon_one_bara[2];	
		$mid_two=$codon_two_bara[0].$codon_two_bara[1].$codon_one_bara[2];
		if($aalist{$one_mid} ne "." and $aalist{$mid_two} ne "."){
			$div++;
			if($aalist{$codon_one} eq $aalist{$one_mid}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$one_mid} eq $aalist{$mid_two}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$mid_two} eq $aalist{$codon_two}){$temp_sys++;}
			else{$temp_non++;}
		}

		$one_mid=$codon_two_bara[0].$codon_one_bara[1].$codon_one_bara[2];	
		$mid_two=$codon_two_bara[0].$codon_one_bara[1].$codon_two_bara[2];
		if($aalist{$one_mid} ne "." and $aalist{$mid_two} ne "."){
			$div++;
			if($aalist{$codon_one} eq $aalist{$one_mid}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$one_mid} eq $aalist{$mid_two}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$mid_two} eq $aalist{$codon_two}){$temp_sys++;}
			else{$temp_non++;}
		}

		$one_mid=$codon_two_bara[0].$codon_one_bara[1].$codon_one_bara[2];	
		$mid_two=$codon_two_bara[0].$codon_two_bara[1].$codon_one_bara[2];
		if($aalist{$one_mid} ne "." and $aalist{$mid_two} ne "."){
			$div++;
			if($aalist{$codon_one} eq $aalist{$one_mid}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$one_mid} eq $aalist{$mid_two}){$temp_sys++;}
			else{$temp_non++;}
			if($aalist{$mid_two} eq $aalist{$codon_two}){$temp_sys++;}
			else{$temp_non++;}
		}
		
		$sys_sub=$sys_sub+$temp_sys/$div;
		$non_sub=$non_sub+$temp_non/$div;
	}
	return($sys_sub, $non_sub);
}



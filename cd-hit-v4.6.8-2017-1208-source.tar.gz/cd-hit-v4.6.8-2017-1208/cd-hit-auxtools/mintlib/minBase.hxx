//=================================================================
// This file is a part of the Minimum Template Library.
// By Limin Fu (phoolimin@gmail.com, lmfu@ucsd.edu)
// Released under the MIT license.
//================================================================= 

#ifndef __MIN_BASE_HXX__
#define __MIN_BASE_HXX__

#define BEGIN_NS_MIN namespace Min {
#define END_NS_MIN }

#endif

#Pre-requisites before using test data

1. install all software

2. change path to sORFfinder in script step2runsORFs.sh

3. put all the test data and scripts in one folder eg: sORFs_fungal

4. run sORFs prediction by sh step2runsORFs.sh